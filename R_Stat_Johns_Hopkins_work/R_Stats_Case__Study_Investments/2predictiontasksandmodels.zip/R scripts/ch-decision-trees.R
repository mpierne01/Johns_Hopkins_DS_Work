### Quick Review of Decision Trees
### Also known as "Classification and
### Regression Trees" (or CART)

###################################################
### clean up the workspace
###################################################
# free memory, first remove all objects
rm(list = ls())
# then perform "garbage collection", relates
# to memory management
gc()

?gc
###################################################
### Allocate iris dataset to training (70%)
### and to Test (30%)
###################################################
data(iris)
str(iris)
set.seed(1234) 
# sample either 1 or 2 150 times with
# 70% chance of 1 and 30% chance of two
ind <- sample(2, nrow(iris), 
              replace=TRUE, 
              prob=c(0.7, 0.3))
# so 70% go into the training set
trainData <- iris[ind==1,]
# and 30% go into the test set
testData <- iris[ind==2,]


###################################################
### Use party package, build decision tree and
### and check prediction result
###################################################
library(party)
# species is target variable (is a classification task)
# and is predicted by all other variables
# which are all numeric
myFormula <- Species ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width
# use ctree() for classification task to train
# the model to classify
iris_ctree <- ctree(myFormula, data=trainData)
# check the prediction with a 'confusion matrix'
# where the rows represent the predicted class
# of the target variable and the columns represent
# the actual class
table(predict(iris_ctree), trainData$Species)

###################################################
### Next we will take a look at the tree by
### printing the rules and plotting the tree
###################################################
print(iris_ctree)

###################################################
### Plot the classification tree
###################################################
plot(iris_ctree)

###################################################
### A different plot: old wine, a new bottle
###################################################
# barplot for each leaf node shows probabilities
# of instance falling into one of three species.
# These are shown as "y" in the leaf nodes. For
# example, in node 2 "n=40, y=(1,0, 0)" means it
# has 40 training instances and all belong to 
# the class 'setosa'
plot(iris_ctree, type="simple")

###################################################
### Test the tree's ability to classify with
### 'new' data, the 30% testData set
###################################################
# predict flower classification on test data
testPred <- predict(iris_ctree, newdata = testData)
table(testPred, testData$Species)

# it does pretty well. Note that ctree() does not
# handle missing data well so you should clean
# NA's up first.

# Also, any variables in the training set must also
# appear in the test set, even if they are absent
# from the observed decision tree. Otherwise, the
# call to predict() will fail.

# Also, the values (or levels) of the categorical
# target variable must be consistent in both the
# train and test sets.

###################################################
### Using rpart package instead of party
###################################################
# We use a new dataset, "bodyfat". Note you must
# have package mboost installed to access the data
data("bodyfat", package = "mboost")
dim(bodyfat) # 71 rows, 10 columns
attributes(bodyfat) # names are variable names
# set has selective numbers as the row.names, not
# to be confused with the sequential ordering of
# the 71 observations
bodyfat[1:5,]

###################################################
### But here target variable is numeric, so could
### call this a regression prediction task instead
### of a classification task.
###################################################
set.seed(1234) 
# use same technique to split data into
# 70% for training and 30% for testing
ind <- sample(2, nrow(bodyfat), 
              replace=TRUE, prob=c(0.7, 0.3))
bodyfat.train <- bodyfat[ind==1,]
# 56 records in training set:
nrow(bodyfat.train)
bodyfat.test <- bodyfat[ind==2,]
# but 15 records in test set
nrow(bodyfat.test)
# train a decision tree
library(rpart)
# predict DEXfat on 5 variables only:
myFormula <- DEXfat ~ age + waistcirc + hipcirc + elbowbreadth + kneebreadth
bodyfat_rpart <- rpart(myFormula, data = bodyfat.train, 
                       control = rpart.control(minsplit = 10))
# have different control parameters using rpart
?rpart
attributes(bodyfat_rpart)
# want to minimize prediction error:
print(bodyfat_rpart$cptable)
print(bodyfat_rpart)


###################################################
### code chunk number 10: ch-decision-trees.rnw:114-116
###################################################
plot(bodyfat_rpart)
# inserts the text into the tree, essentially
# providing same information as before. This is a
# 'full' or 'bushy' tree which will be 'pruned'
text(bodyfat_rpart, use.n=T)

###################################################
### Generally you will "prune" the tree
###################################################
# want to select the tree with the minimum
# prediction error:
opt <- which.min(bodyfat_rpart$cptable[,"xerror"])
# 7th record
opt
# cp is complexity parameter
cp <- bodyfat_rpart$cptable[opt, "CP"]
cp
bodyfat_prune <- prune(bodyfat_rpart, cp = cp)
?prune
print(bodyfat_prune)
# here is the 'pruned' tree
plot(bodyfat_prune)
text(bodyfat_prune, use.n=T)


###################################################
### Use the pruned tree to predict; Compare
### predicted with actual on testset
###################################################
DEXfat_pred <- predict(bodyfat_prune, newdata=bodyfat.test)
xlim <- range(bodyfat$DEXfat)
# predicted versus 'observed' or 'actual'
plot(DEXfat_pred ~ DEXfat, data=bodyfat.test, xlab="Observed", 
     ylab="Predicted", ylim=xlim, xlim=xlim)
abline(a=0, b=1)


###################################################
### Random Forests
###################################################
# do the same drill again with iris dataset
ind <- sample(2, nrow(iris), replace=TRUE, prob=c(0.7, 0.3))
trainData <- iris[ind==1,]
testData <- iris[ind==2,]


###################################################
### Use randomforest package
###################################################
library(randomForest)
# cannot handle missing data so you must impute
# any missing values first. Also, there is a limit of
# 32 maximum levels of the target categorical variable
# (which is a lot !)

# Could also use function cforest() in party package

# classify based on all variables with 100 trees
rf <- randomForest(Species ~ ., data=trainData, ntree=100, proximity=TRUE)
# look at confusion matrix; 'ensemble' methods are
# generally have less prediction error
table(predict(rf), trainData$Species)
print(rf)
attributes(rf)

###################################################
### How many trees do you need? Plot the error rate
### with various numbers of trees. The colors are the
### different species
###################################################
plot(rf)


###################################################
### Which variables are more 'important' in the
### prediction? Look at mean decrease in Gini criterion
###################################################
importance(rf)
varImpPlot(rf)
# Petal Width is most important

###################################################
### Try it out on the test data
###################################################
irisPred <- predict(rf, newdata=testData)
table(irisPred, testData$Species)
plot(margin(rf, testData$Species))

# The margin of a data point is the proportion
# of votes for the correct class minue maximum 
# proportion of votes for other classes.

# Generally speaking, positive margin means correct
# classification

