########################################
##### CASE STUDIES IN DATA MINING: #####
#####  A SHORT INTRODUCTION TO R   #####
#####       AND DATA MINING        #####
########################################

### LEARN R BY DOING !

# get the book-associated R packages
install.packages("DMwR")
library("DMwR")

# see what version of R you are running:
R.version

### A SHORT INTRODUCTION TO R
# R is a functional language (with object-
# oriented elements) for statistical
# computation, data analysis and graphics.

# R is an interpreted language with compiled
# snippets of C embedded (for speed)

# to see what packages are installed
installed.packages()

# this also works and has shorter output
library()

# to check whether there are newer versions
# of your installed packages at CRAN:
old.packages()

# help
?lm
############# Copy in Following Example
############# from Help Screen ("Cheat Sheet")
############# for the lm() function

require(graphics)

## Annette Dobson (1990) "An Introduction to Generalized Linear Models".
## Page 9: Plant Weight Data.
ctl <- c(4.17,5.58,5.18,6.11,4.50,4.61,5.17,4.53,5.33,5.14)
trt <- c(4.81,4.17,4.41,3.59,5.87,3.83,6.03,4.89,4.32,4.69)
group <- gl(2, 10, 20, labels = c("Ctl","Trt"))
weight <- c(ctl, trt)
lm.D9 <- lm(weight ~ group)
lm.D90 <- lm(weight ~ group - 1) # omitting intercept

anova(lm.D9)
summary(lm.D90)

opar <- par(mfrow = c(2,2), oma = c(0, 0, 1.1, 0))
plot(lm.D9, las = 1)      # Residuals, Fitted, ...
par(opar)

### End of Copied Example from Interactive
### lm() Function Help Sheet in R
### Can evoke help with ? for example ?lm

### R Objects

# Have Objects and Functions

# Objects are "things"; Functions perform actions, tasks

# An object is a storage space with an associated name.

# Everything in R is stored in an object.

# Functions are a special type of R objects
# that carry out an operation

# Everything, all variables, data, functions, etc
# are stored in random access memory of the computer
# as named objects.

# assignment operator known as "gets" symbol
# stores numeric value 945 in variable (an object) x
x <- 945
x

# or '=' almost the same as '<-'
y = 643; y # comment symbol ';' marks a new line to R

# can assign numerical expressions to an object
# Here the object w stores the result of the expression
z <- 5
w <- z^2 # '^' is exponentiation
w

# Here assignment operator means "calculate whatever
# is expressed on right side of operator, and assign
# (or store) the result of the calculation to the
# object that is named on the left side
i <- (z * 2 + 45)/2

# can use R an an interactive calculator by
# not assigning result to an object
(34 + 90)/12.5

# can see objects in workspace (memory) with ls()
ls()

# objects persist until you delete them
rm(y)
rm(z, w, i)

#### DATA STRUCTURES

### Vectors
# Vectors are default data structure in R
x <- 16.4 # creates a vector
x

# All objects have a mode and length

# Mode determines the type of data stored in an object

# Length is how many elements are stored in the object

# Vectors are used to store a set of elements
# of the same atomic data type. They must be
# the same atomic data type in a vector.

# Main atomic data types are character, logical,
# numeric or complex

my.friends <- c("bob", "mary", "joe")
?c
my.friends
length(my.friends)
mode(my.friends)

v <- c(5, 3, 8, 78); v
length(v)
mode(v)
typeof(v)

# All elements of a vector must 
# belong to the same mode. 
# If that is not true, R will try to "coerce" it 
# to all be of the same mode.
# The following is an example of this,
v <- c(4,7,23.5,76.2,80,"rrt")
v

# All vectors may contain a special 
# value named NA. This represents a missing
# value
v <- c(NA,"rrr")
v

u <- c(4,6,NA,2)
u

t <- c(v, u)
t

k <- c(T,F,NA,TRUE)
k

# You may access a particular element of a 
# vector through an index, accessing 
# individual elements
v[2]


# can change the value of one 
# particular vector element, Changing an element
v[1] <- 'hello'
v

# can create empty vectors like this
a <- vector()
a

# can change length of a vector
# by simply adding more elements to it
# using a previously non-existing type
a[3] <- 45
a

# can shrink the size of a vector 
# using the assignment operation. 
# The assignment operator can be
# used destructively
v <- c(45,243,78,343,445,645,2,44,56,77)
v

v <- c(v[5],v[7])
v

### VECTORIZATION

# is a big deal ! makes things faster !

# R has vectorized functions which operate
# on every element of a vector; ie. process
# the entire vector using byte conversion

v <- c(4,7,23.5,76.2,80)
x <- sqrt(v)
x

# function sqrt() calculates square root 
# of its argument. In this case we have
# used a vector of numbers as its argument. 

# Vectorization leads the function to produce
# a vector of the same length, with each 
# element resulting from applying the
# function to every element of the original 
# vector.

# You may also use Vector arithmetic 
# this feature of R to carry out vector 
# arithmetic,
v1 <- c(4,6,87)
v2 <- c(34,32.4,12)
v1+v2

# What if the vectors do not have the 
# same length? R will use a recycling rule
# by repeating the shorter vector until it 
# fills in the size of the larger. 
v1 <- c(4,6,8,24)
v2 <- c(10,2)
v1+v2

# It is as if the vector c(10,2) 
# was c(10,2,10,2). If the lengths are not
# multiples than a warning is issued,
v1 <- c(4,6,8,24)
v2 <- c(10,2,4)
v1+v2

# Geoff says: 
# "Warnings are your friends!"

# Geoff adds: 
# "Errors are NOT your friends!"

# Remember, single numbers are represented
# in R as vectors of length 1.

v1 <- c(4, 6, 8, 24)
2 * v1

# By the way, in almost all cases, blank
# spaces are ignorred in R
v1<-c(4,6,8,24)
2*v1
sqrt(49)
sqrt ( 121 )
s q r t (49)  # NOPE ! (Not your friend !)

#####  FACTORS

# For Storing, using, handling categorical
# data. Are useful in datasets with nominal
# variables with a fixed number of possible
# values

# Can use and show values of nominal variables
# as they really are, but they are stored
# as numeric vectors

# Both nominal categories (no order)
# And ordinal categories ('ordered factor')

# Nominal factors have 'levels'

# vector with gender of 10 individuals
g <- c("f","m","m","m","f","m","f","m","f","f")
typeof(g)

# transform it to a factor
g <- factor(g)
g

levels(g)

?ordered

# coerce it into an ordered factor
g <- as.ordered(g)
g

# have two levels, "f" and "m" which
# are stored as 1 and 2 respectively

# Can define levels even if not used
# Are "saving them 'til later":
other.g <- factor(c("m","m","m"), 
                  levels = c("m","f","o"))
other.g

other.g[4] <- "f"
other.g

other.g[5] <- "o"
other.g

other.g[6] <- "n"
other.g # not the same as 'NA'
        # '<NA>' means never existed
        # the term 'NA' means missing

# cab count the occurrence frequency tables 
# for each possible value. Try this:
table(g)

table(other.g)

# table() function can also be used to 
# obtain cross-tabulation of several
# factors. Suppose that we have in another 
# vector the age category of the 10
# individuals stored in vector g. You 
# could cross tabulate these two vectors as
# follows
a <- factor(c("adult","adult","juvenile",
              "juvenile","adult","adult",
              "adult","juvenile","adult",
              "juvenile"))
a

table(a,g)

# The following gives you the totals for 
# both the sex and the age
# factors of this data
t <- table(a,g)
margin.table(t,1)

margin.table(t,2)

# For relative frequencies with respect to each 
# margin and overall we do:
prop.table(t,1) # if we wanted percentages:
prop.table(t,1)*100

prop.table(t,2) # percentages:
prop.table(t,2)*100

prop.table(t) # percentages
prop.table(t)*100

### Generating Sequences
x <- 1:1000; x

# creates a vector x containing 1000 elements, 
# the integers from 1 to 1000.

# be careful with the precedence of 
# the operator ":". The following
# examples illustrate this danger,
10:15-1

10:(15-1)

# may also generate decreasing sequences :
5:0

# To generate sequences of real numbers you can 
# use the function seq():

seq(-4,1,0.5)
?seq
# generates a sequence of real numbers 
# between -4 and 1 in increments of 0.5.

# Other examples:
seq(from=1,to=5,length=4)

seq(from=1,to=5,length=2)

seq(length=10,from=-2,by=.2)

# Another very useful function to generate
# sequences is the function rep(), sequences
# with repeated numbers
rep(5,10)
?rep
rep("hi",3)

rep(1:3,2)

# The function gl() can be used to generate 
# sequences involving factors. The Factor sequences
# syntax of this function is gl(k,n), where k is 
# the number of levels of the factor, and n is
# the number of repetitions of each level. 

# Here are two examples:
gl(3,5)

gl(2,5,labels=c('female','male'))

# Finally, R has several functions that can be 
# used to generate random sequences according
# to a Random sequences large set of probability 
# density functions. The functions have the
# generic structure rfunc(n, par1, par2, ...), 
# where func is the name of the density function, 
# n is the number of data to generate, and
# par1, par2, ... are the values of some parameters 
# of the density function that may be necessary. 

# For instance, if you want 10 randomly generated 
# numbers from a normal distribution with zero 
# mean and unit standard deviation, enter
set.seed(123)
rnorm(10)

# if you prefer a mean of 10 and a standard 
# deviation of 3, you should use
rnorm(100,mean=10,sd=3)

# To get 5 numbers drawn randomly from a 
# Student t distribution with 10 degrees of
# freedom, type
rt(5,df=10)

# R has many more probability functions, as well 
# as other functions for obtaining probability 
# densities, the cumulative probability densities 
# and the quantiles of these distributions.

### Indexing (also known as Sub-Setting)

# Have flexibility what to use within brackets
# can use vectors, logical index vectors extract
# the elements corresponding to true values
x <- c(0,-3,4,-1,45,90,-5)

# this is a logical condition for all elements
# of the vector x
x > 0

# this vector of logical values as index
# to x returns positions of x corresponding
# to true values
x[x>0]

# give me positions of x for which
# following logical expression is true:
# this is a logical disjunction:
x[x <= -2 | x > 5]

# can build quite complex logical operators:
# this is a logical conjunction:
x[x > 40 & x < 100]

# can use a vector of integers to extract several
# elements from a vector. The numbers in the vector
# on indexes indicate which positions to extract:
x[c(4,6)]
x[1:3]
y <- c(1,4)
x[y]

# can also use a vector with negative numbers
# to 'suppress' (or "not extract," does not remove
# them)
x[-1]
x[-c(4,6)]

# note need for parentheses due to
# precedence of ":" operator
x[-(1:3)]

# Indexes can be formed by vector of strings
pH <- c(4.5,7,7.3,8.2,6.3);pH

# Can name vector elements through
# function names()
names(pH) <- c('area1','area2','mud','dam','middle')
pH

# But if you already know names
# of positions of vectors intially,
# it is better to do this:
pH <- c(area1=4.5,area2=7,mud=7.3,dam=8.2,
        middle=6.3)
pH

# Now can index vector pH using names
pH['mud']
pH[c('area1','dam')]

### Matrices and Arrays
# Can store data elements in an object with
# more than one dimension.

# Arrays are multi-dimensional.
# A matrix is a two-dimensional array.
# Both arrays and matrices are simply vectors
# with a "dimension" attribute:
m <- c(45,23,66,77,33,44,56,12,78,23)
m

# set the dimensions to be 2 rows, 5 columns:
# Fills the matrix by columns by default
dim(m) <- c(2,5)
m

# simpler way to build same matrix:
m <- matrix(c(45,23,66,77,33,44,56,
              12,78,23),2,5)
m

# can fill by rows using byrow argument
m <- matrix(c(45,23,66,77,33,44,56,
              12,78,23),2,5,byrow=T)
m

# can access elements of matrix through similar
# indexing as with vectors but now use two indexes
m[2,3]

# you can also subset and suppress certain elements
# "do not take second row and take first column":
m[-2,1]

# take first row without columns 3 or 5
m[1,-c(3,5)]

# if you omit a dimension, you get everything
# "all of first row":
m[1,]

# "all of fourth column":
m[,4]
# note you end up with a vector
# If you want result to be a matrix:
# Still first row but is a matrix:
m[1,,drop=F]
# Still fourth column, but is a matrix:
m[,4,drop=F]

# cbind() and rbind() can join vectors and
# matrices, by columns or rows, respectively
m1 <- matrix(c(45,23,66,77,33,44,56,
               12,78,23),2,5)
m1

# bind the column 4 and 76 with the existing
# fourth column:
cbind(c(4,76),m1[,4])

# create matrix 4 rows, 5 cols, all 10s:
m2 <- matrix(rep(10,20),4,5)
m2
# bind the 1st row of m1 and the 
# 3rd row of m2 into m3:
m3 <- rbind(m1[1,],m2[3,])
m3

# can assign names to the cols and rows
# of a matrix with colnames() and rownames()
results <- matrix(c(10,30,40,50,43,
                    56,21,30),2,4,byrow=T)
# name the columns of results
colnames(results) <- c('1qrt','2qrt','3qrt','4qrt')
# name the rows of results
rownames(results) <- c('store1','store2')
results
# first row of results:
results['store1',]
# second row, 1st and 4th column
results['store2',c('1qrt','4qrt')]

# arrays are extensions of matrices and
# can have more than two dimensions, so they
# can have more than two indexes:
a <- array(1:24,dim=c(4,3,2))
a

# 1st row, 3rd column of second repeat
a[1,3,2]

# first row, all columns, 2nd repeat
a[1,,2]

# 4th row, 3rd column, all repeats
a[4,3,]
a[c(2,3),,-2]

# Can be confusing

# The recycling and arithmetic rules apply:
m <- matrix(c(45,23,66,77,33,44,56,
              12,78,23),2,5)
m
# multiplies each element by 3:
m*3

# Create m1:
m1 <- matrix(c(45,23,66,77,33,44),2,3)
m1

# Create m2
m2 <- matrix(c(12,65,32,7,4,78),2,3)
m2

# add them together, same thing, element
# by element:
m1+m2

### List Structures

# A list is an ordered collection of other objects
# known as components/ Unlike vectors, list
# components do not have to be of the same type

# Components of lists are always indexed
# with numbers and also may have named
# components 

my.lst <- list(stud.id=34453, 
               stud.name="John", 
               stud.marks=c(14.3,12,15,19))
my.lst

# What is the value of first component?
# Can extract individual elements of list
my.lst[[1]]
my.lst[2]
# value of third component?
my.lst[[3]]

# what is name and value of first component?
# Distinction between [1] and [[1]]
my.lst[1]

# Single bracket is a sublist formed
# from the first component of my.lst
mode(my.lst[1])

# double bracket extracts the value
# of the first component which is numeric
mode(my.lst[[1]])

# if components are named (as above), can
# extract value of named component like this
my.lst$stud.id

# returns the names of components, they are
# an attribute of the list
names(my.lst)

# can use names attrib to assign new names
names(my.lst) <- c('id','name','marks')
my.lst

# Can always add a component to an S3 object list:
my.lst$parents.names <- c("Ana","Mike")
my.lst

# returns the number of components
length(my.lst)

# returns length of each component
sapply(my.lst,length)

# can remove a component
my.lst <- my.lst[-4]
my.lst

# can concatenate lists
# Create list 'other'
other <- list(age=19,sex='male')
# Concatenate 'other' with 'my.lst',
# assign new concatenated list to lst
lst <- c(my.lst,other)
lst

# Squashes list flat...makes it a vector.
# Creates a vector with as many data elements
# as there are objects in the original list
my.lst <- unlist(my.lst)

### Data Frames

# Used for storing data tables
# Two-dimensional like matrices but
# columns can be different data types.
# Actually, they are a specialized list structure:
my.dataset <- data.frame(site=c('A','B','A','A','B'),
                         season=c('Winter','Summer',
                                  'Summer','Spring','Fall'),
                         pH = c(7.4,6.3,8.6,7.2,8.9))

# each row is a case, each column a variable
my.dataset

# data frames do not like string variables,
# coerces them into a factor:
my.dataset[3,2]

# Similarly 'site' column is a factor.
# This is default behavior of data.frame() function

# can access by index or name, need $ to
# reference a particular variable as whole vector
my.dataset$pH

# Note versatility and power of indexing
# (also called 'subscripting').

# Can effectively query the data by subsetting
my.dataset[my.dataset$pH > 7,]
my.dataset[my.dataset$site == 'A','pH']
my.dataset[my.dataset$season == 'Summer',
           c('site','pH')]

# Can simplify querying using attach() function
attach(my.dataset)
# no longer need 'long' name of variable
my.dataset[site == 'B',]
season

# inverse of attach is detach
detach(my.dataset)
season

# use of the subset() function is a simpler
# was to query the dataframe
subset(my.dataset,pH > 8)
subset(my.dataset,season == 'Summer',season:pH)

# but you cannot use subset to change
# values in the data, so if you want to sum
# 1 to the pH values of all summer rows, you
# must do it like this:
my.dataset[my.dataset$season == 'Summer','pH'] <- 
  my.dataset[my.dataset$season == 'Summer','pH'] + 1

# you can add new columns just as with lists,
# but they must have the same # of rows
my.dataset$NO3 <- c(234.5,256.6,654.1,356.7,776.4)
my.dataset

# mismatch in number of rows
my.dataset$NO4 <- c(234.6,654.1,356.7,776.4)
my.dataset

# state # of rows:
nrow(my.dataset)
# state number of columns:
ncol(my.dataset)

# variable (column) names
names(my.dataset)
names(my.dataset) <- c("area","season","pH","NO3" )
my.dataset

# can change the name of variable using subscript
names(my.dataset)[4] <- "PO4"
my.dataset

# Can view 'built in' datasets:
data()

# to use any of these you would say,
# for example
data(USArrests)

# and then you can 'see' USArrests
# in your workspace

### Can create your own functions
# Given a vector of values, we want a function
# to calculate the standard error
se <- function(x) {
  v <- var(x)
  n <- length(x)
  return(sqrt(v/n))
}

# Let's apply it to this vector
se(c(45,2,3,5,76,2,4))

# Parameter 'more' has default value FALSE
# The 'more' argument is optional
basic.stats <- function(x,more=F) {
  # initialize variable to hold results
  # Use of list common, can hold an
  # irregularly-sized structure 
  # comprised of different data types
  stats <- list()
  # strips out missing values:
  clean.x <- x[!is.na(x)]
  # determine number of elements in original vector
  stats$n <- length(x)
  # dtermine how many were 'cleaned" (omitted)
  stats$nNAs <- stats$n-length(clean.x)
  # take the mean of clean
  stats$mean <- mean(clean.x)
  # figure std dev of clean
  stats$std <- sd(clean.x)
  # determine median
  stats$med <- median(clean.x)
  # introduce conditional if statement
  # statement in if only execute if more is TRUE
  if (more) {
    # gets measure of skew
    stats$skew <- sum(((clean.x-stats$mean)/stats$std)^3)/length(clean.x)
    # gets measure of kurtosis (peakedness)
    stats$kurt <- sum(((clean.x-stats$mean)/stats$std)^4)/length(clean.x) - 3
  }
  # squashes and returns the list;
  # A function returns the last statement
  # executed unless you use return()
  unlist(stats)
}

# Let's try it
basic.stats(c(45,2,4,46,43,65,NA,6,-213,-3,-45))
# Same data but more=TRUE
# Get skew and kurt
basic.stats(c(45,2,4,46,43,65,NA,6,-213,-3,-45),more=T)

# for statement allows us to repeat a set
# of commands

f <- function(x) {
  for(i in 1:10) {
    res <- x*i
    # cat is flexible print function
    # \n throws a line
    cat(x,'*',i,'=',res,'\n')
  }
}

f(5)
f(c(5,7))