###################################################
###       Predicting Stock Market Returns       ###
###                 Session #2                  ###
###################################################


### But which predictors should we use?

# We have defined an indicator (T) that summarizes the 
# behavior of the price time series in the next k days. 

# But our data mining goal is to predict this behavior.
# That is, we want to predict the future behavior of
# the market based on the past observed behavior.

# So how do we describe the recent price pattern? (p in
# example above). We can use multiple predictors instead
# of a single summarized predictor.

# The simplest type of information we can use are the
# recent observed prices.....are many 'technical indicators'
# in R package TTR. So which technical features do w
# choose? We will define an initial set of features and 
# then use estimate the importance of each feature. 
# Based on these estimates we will select the most 
# relevant features.

# We center on Close quote since buy/sell is done at end
# of each day. The h-day (arithmetic) returns are calculated
# as:

# Ri-h = (Ci - Ci-h) / Ci-h where Ci is close price
# at session i. 

# we have selected a representative set of technical
# indicators, from those available in package TTR:
# the Average True Range (ATR), an indicator of volatility of the series;
# the Stochastic Momentum Index (SMI), which is momentum indicator; the
# Welles Wilder's Directional Movement Index (ADX); 
# the Aroon indicator that tries to identify starting trends; 
# the Bollinger Bands that compare the volatility over time;
# the Chaikin Volatility; 
# the Close Location Value (CLV) that relates the session Close to its trading range; 
# the Arms' Ease of Movement Value (EMV); 
# the MACD oscillator; 
# the Money Flow Index (MFI);
# the Parabolic Stop-and-Reverse; and 
# the Volatility indicator.

# We boil these down to a single value for each one.

myATR <- function(x) ATR(HLC(x))[,'atr']
mySMI <- function(x) SMI(HLC(x))[,'SMI']
myADX <- function(x) ADX(HLC(x))[,'ADX']
myAroon <- function(x) aroon(x[,c('High','Low')])$oscillator
myBB <- function(x) BBands(HLC(x))[,'pctB']
myChaikinVol <- function(x) Delt(chaikinVolatility(x[,c("High","Low")]))[,1]
myCLV <- function(x) EMA(CLV(HLC(x)))[,1]
myEMV <- function(x) EMV(x[,c('High','Low')],x[,'Volume'])[,2]
myMACD <- function(x) MACD(Cl(x))[,2]
myMFI <- function(x) MFI(x[,c("High","Low","Close")], x[,"Volume"])
mySAR <- function(x) SAR(x[,c('High','Close')]) [,1]
myVolat <- function(x) volatility(OHLC(x),calc="garman")[,1]

# The variables we have just described form the
# initial set of predictors for task of forecasting
# the future value of the T indicator. We try to
# reduce this set of 22 variables using a 
# feature selection method with random forests.

# RFs can also be used to estimate the relative
# importance of each feature in the prediction task.

# we will split the available data into two separate
# sets: (1) one used for constructing the trading system; 
# and (2) another to test it. The first set will be formed 
# by the first 30 years of quotes of S&P 500. We use
# remaining data (around 9 years) for the final test
# of our trading system.

# make sure you have access to the data or you will get errors
data(GSPC)
library(randomForest)
library(quantmod) # which also loads TTR
# starts by specifying and obtaining the data to be
# used for modeling using specifyModel() function to create
# quantmod object that is our model:
data.model <- specifyModel(T.ind(GSPC) ~ Delt(Cl(GSPC),k=1:10) + myATR(GSPC) + mySMI(GSPC) + myADX(GSPC) + myAroon(GSPC) + myBB(GSPC)  + myChaikinVol(GSPC) + myCLV(GSPC) + CMO(Cl(GSPC)) + EMA(Delt(Cl(GSPC))) + myEMV(GSPC) + myVolat(GSPC)  + myMACD(GSPC) + myMFI(GSPC) + RSI(Cl(GSPC)) + mySAR(GSPC) + runMean(Cl(GSPC)) + runSD(Cl(GSPC)))

# Note: you will likely get some NaNs returned from the above command
# This is not fatal but may result in results slightly different
# from the "book version"

# so we get consistent results run to run:
set.seed(1234)
# buildModel() uses the model specification to obtain model with
# corresponding data. Parameter training.per helps us specify which
# data should be used to obtain the model (overall are using 1st 30 years)
rf <- buildModel(data.model,method='randomForest',
             training.per=c(start(GSPC),index(GSPC["1999-12-31"])),
             ntree=50, importance=T)

# 50 trees in the RF model, importance=T will give us the
# relative importance of the features

# in RF model building function above, buildModel contains
# wrappers for several modeling tools that use Rfs. If you
# want to use a model that is not contemplated by buildModel()
# you can use modelData() which will obtain a standard zoo
# object. We us specifyModel() here just to obtain some IBM data:
ex.model <- specifyModel(T.ind(IBM) ~ Delt(Cl(IBM),k=1:3))
# and then apply it to the ex.model output using modelData()
data <- modelData(ex.model,data.window=c('2009-01-01','2009-08-10'))

# Note the formula as the argument to specifyModel() is NOT
# the same as the longer one we used above...we are just
# fetching more data.

# In regression with random forests in R, the importance of
# variables with two alternative scores:
# (1) % increase in error (mean squared error) of each tree
# on out-of-bag sample when each variable is removed; this
# increase is averaged over all trees in the forest and
# normalized with the standard error.
# (2) 'decrease in node impurity accountable with variable'
# again averaged over all trees and normalized

# We use first variable and gauge importance of input variables.
# Arguments to varImpPlot() are the random forest and the
# score we wish to plot....result is a plot of the relative
# importance of variables according to the random forest
varImpPlot(rf@fitted.model,type=1)

# we need to decide on a threshold of importance score to
# select only the features we will use. Looking at the plot,
# we choose value of 10 as the threshold:
imp <- importance(rf@fitted.model,type=1)
rownames(imp)[which(imp > 10)]

# function importance() fetchs the importance score for
# each variable which we then filter using 10 threshold
# criteria to obtain names of variable to use in our
# models (Note: Book example, which we will continue to use,
# only returned eight of the variables, not nine....this
# could be from the warnings about NaNs produced.....)

# Then we obtain our final dataset using those variables (we change model
# from the book model since we obtained a slightly different mix of
# "importance variables"):
# this is book model
#data.model <- specifyModel(T.ind(GSPC) ~ Delt(Cl(GSPC),k=1) + myATR(GSPC) + myADX(GSPC) + myEMV(GSPC) + myVolat(GSPC) + myMACD(GSPC) + mySAR(GSPC) + runMean(Cl(GSPC)) )

# we use this model with the top eight importance variables
# that I achieved running it several times:
data.model <- specifyModel(T.ind(GSPC) ~ myVolat(GSPC) + myMACD(GSPC) + mySAR(GSPC) + runSD(Cl(GSPC)) + myATR(GSPC) + myMFI(GSPC) + RSI(Cl(GSPC)) + runMean(Cl(GSPC)) )

# Again, you might get more NaNs produced.....again, not fatal
# or even really a problem although it makes the results slightly
# different from "the book version"...

### The Prediction Tasks

# So now we have obtained a quantmod object (data.model)
# the data we plan to use with our predictive models. 
# This data has as a target the value of the T indicator 
# and as predictors a series of other variables that resulted
# from a feature selection process. But our real goal is to 
# predict the correct trading signal at any time t.

# How can we do that, given the data we have generated ?

# One alternative is to use the T value as the target variable 
# and try to obtain models that forecast this value using 
# the predictors information. This is a multiple regression
# task. If we follow this path, we will have to "translate" 
# our model predictions into trading signals. 

# This means to decide upon the thresholds on the predicted
# T values that will lead to either of the three possible 
# trading actions. We will carry out this transformation:

# signal is sell if T < 0.01
# signal is hold if -0.1 <= T <= 0.1
# signal is buy if T > 0.1

# These T values are arbitrary but these values mean that 
# during the 10 day-period used to generate the T values, 
# there were at least four average daily prices that
# are 2.5% above the current close (4 x 0.025 = 0.1).

# We could also use a nominal variable as the target in
# a classification task, but the xts package infrastructure 
# is geared toward numeric data so we stick with plan 'A' above.

# Here we all the data structures that we will use
# subsequently for obtaining predictive models:

# 30 years training data:
Tdata.train <- as.data.frame(modelData(data.model,
                       data.window=c('1970-01-02','1999-12-31')))
# 9 years of testing data:
Tdata.eval <- na.omit(as.data.frame(modelData(data.model,
                       data.window=c('2000-01-01','2009-09-15'))))

# here is our prediction model formula:
Tform <- as.formula('T.ind.GSPC ~ .')

# The Tdata.train and Tdata.eval are data frames with 
# the data to be used for the training and evaluation.
# For these tasks we will replace the target value column
# with the corresponding signals that will be generated 
# using the trading.signals() function

# The Tdata.eval data frame will be left out of all model
# selection and comparison processes we carry out. 

# It will be used in the final evaluation of the "best"
# models we select. The call to na.omit() is needed to avoid
# NAs at the end of the data frame caused by lack of future
# data to calculate the T indicator.

###################################################
### Precision and Recall, Confusion Matrices
###################################################

# So far we are using a regression task which predicts a number.
# But we will cast this number into a signal by a thresholding 
# mechanism. So we must address the question of how to evaluate 
# the signal predictions of our models.

# We evaluate the signal predictions by looking at the
# error rate, defined as 

# error.rate = 1/N times the sum (as i goes from 1 to N) of
# Lo/1(ysubi,yhat-subi)

# where yhat-subi is the prediction of the model for the test
# case i (labeled ysubi), and Lo/1, known as the 0/1 loss
# function:

# Lo/1(ysubi,yhat-subi) = 1 if yhat-subi is not equal to ysubi
# or Lo/1 = 0 if yhat-subi is equal to ysubi

# One often uses the complement of this loss function, known
# as accuracy, and given by 1 - error.rate

# These statistics compare the model predictions to what really
# happened in the markets in the k future trading days.

# Since hold signals predominate over buy or sell signals,
# accuracy is not a very interesting trading measure. We
# would want to have models measured as 'accurate' at the
# more rare signals 'buy' and 'sell'/

# So we are really looking at financial market forecasting
# driven by rare events. Event-based prediction tasks are better
# evaluated by precision and recall.

# 'Precision' is the proportion of event signals produced by
# the models that are correct. 'Recall' is the proportion of
# events occurring in the domain signaled by the models (look at Wikipedia).

# Can calculate precision and recall using confusion matrices:

#                   Predictions
#                sell  hold  buy
#  True   sell   ns,s  ns,h  ns,b   Ns,.
# values  hold   nh,s  nh,h  nh,b   Nh,.
#          buy   nb,s  nb,h  nb,b   Nb,.
#                N.,s  N.,h  N.,b   N

# Precision is ns,s + nb,b / N.,s + N.,b

# Recall is ns,s + nb,b / Ns,. + Nb,.

# Precision and Recall can also be calculated separately
# for the buy and sell signals as

# Precision (buy) is nb,b / N.,b
# Precision (sell) is ns,s / N.,s
# Recall (buy) is nb,b / Nb,.
# Recall (sell) is ns,s /Ns,.

# Also can merge precision and recall into a single stat:

# F = (B2+1) x Prec x Rec / B2 x Prec x Rec where 0 <= B <= 1
# That is, B is in between 0 and 1 and controls the relative
# importance of recall to precision.

###################################################
### The Prediction Models
###################################################

# The selection of models was mainly guided by the fact
# that these techniques are well known by their ability
# to handle highly nonlinear regression problems.

### How Will we use the Training Data ?

# Complex time series problems pose particular modeling
# challenges due to strong variability, sometimes
# called "non-stationarities"

# We are forecasting a price time series, so we want a 
# strategy to overcome the negative tendencies of these
# "non-stationarities"

# We look at transformation techniques applied to the time
# series to eliminate some of the effects.

# In time series problems there is an implicit (time) ordering 
# among the test cases. In this context, it makes sense to assume 
# that when we are obtaining a prediction for time i, all test 
# cases with time tag k < i already belong to the past.

# So it is safe to assume that we already know the true value
# of the target variable of these past test cases and that we
# can safely use this information. So, if at some time m of the 
# testing period we are confident that there is a regime shift 
# in the time series, then we can incorporate the information
# of all test cases occurring before m into the initial training
# data, and with this refreshed training set that contains 
# observations of the "new" regime, somehow update our predictive 
# model to improve the performance on future test cases.

# One form of updating the model could be to change it in
# in order to take into account the new training cases. These 
# approaches are usually known as "incremental learners" as they 
# adapt the current model to new evidence instead of starting
# over.

# Assuming that we will use a re-learn approach, we have
# essentially two forms of incorporating the new cases into out
# training set. 

# The 'growing window' approach simply adds them to the current
# training set, thus constantly increasing the size of this set.

# A problem of this approach lies in the fact that as we are assuming
# that more recent data is going to be helpful in producing better models,
# we may also consider whether the oldest part of our training data may 
# be outdated and contribute to decreasing the accuracy of the models.

# The 'sliding window' approach deletes the oldest data of the training
# set at the same time it incorporates the fresher observations so it
# maintains a training set of constant size.

# But when do we adapt the model and incorporate the 'fresher' data?

# There are two ways of answering this question. The first involves 
# estimating this time by checking if the performance of our current 
# model is starting to degrade. 

# Another simpler approach consists of updating the model on a regular 
# time basis, let's say, every w test case, we obtain a new model with 
# fresher data. In this case study we follow this simpler method.

# So to summarize....for each model that we will consider, we will 
# apply it using three different approaches: (1) single model for 
# all test periods, (2) growing window with a fixed updating step of 
# w days, and (3) sliding window with the same updating step w.

###################################################
### Artificial Neural Networks (ANNs)
###################################################

# Artificial neural networks (ANNs) are frequently used in 
# financial forecasting because of their ability to deal with 
# highly nonlinear problems. We use package 'nnet'

# ANNs are formed by a set of computing units (the neurons) linked 
# to each other. Each neuron executes two consecutive calculations: 
# a linear combination of the inputs, followed by a nonlinear 
# computation of the result to obtain its output value that is 
# then fed to other neurons in the network. Each of the neuron
# connections has an associated weight. 

# Constructing an artificial neural network consists of establishing 
# an architecture for the network and then using an algorithm to
# find the weights of the connections between the neurons.

# So-called 'Feed-forward' artificial neural networks have their 
# neurons organized in layers. The first layer contains the input 
# neurons of the network. The training observations of the problem
# are presented to the network through these input neurons.

# The final layer contains the predictions of the neural network
# for any case presented at its input neurons. In between, we have 
# one or more "hidden" layers of neurons. The weight updating 
# algorithms, such as the back-propagation method, try to obtain 
# the connection weights that optimize a certain error criterion. 

# This is accomplished by an iterative process of presenting 
# several times the training cases at the input nodes of the
# network, and after obtaining the prediction of the network
# at the output nodes and calculating the respective prediction 
# error, updating the weights in the network to try to improve 
# its prediction error. This iterative process is repeated until
# some convergence criterion is met.

# ANNs are known to be sensitive to different scales of the 
# variables used in a prediction problem. So we transform the data
# before giving them to the network, in order to avoid eventual 
# negative impacts on the performance. In our case we normalize the 
# data to make all variables have a mean value of zero and a standard 
# deviation of one.

# The function scale() can be used to carry out this transformation 
# for the data. In the nnet package you can also use the function 
# unscale() that inverts the normalization process putting the values 
# back on the original scale.

# so we get replicable results:
set.seed(1234)
library(nnet)
# normalize each column (variable):
norm.data <- scale(Tdata.train)

# we use the first 1,000 cases to obtain the network
# and test the model on the following 1,000.
?nnet
# After normalizing our training data, we call
# function nnet() to obtain the model:
nn <- nnet(Tform, norm.data[1:1000,], size=10, decay=0.01, maxit=1000, linout=T, trace=F)

# The first two parameters are the usual of any modeling function
# in R: the functional form of the model specified by a formula,
# and the training sample used to obtain the model. We have also
# used the parameter size which allows us to specify how many nodes 
# the hidden layer will have. The parameter decay controls the
# weight updating rate of the back-propagation algorithm.
# Finally, the parameter maxit controls the maximum number of 
# iterations the weight convergence process is allowed, the linout=T 
# setting tells the function that we are handling a
# regression problem. The trace=F is used to avoid some of the output
# during the optimization process.

# The function predict() can be used to obtain the predictions 
# of the neural network for a set of test data. 
norm.preds <- predict(nn,norm.data[1001:2000,])

# We obtain these predictions and then we convert them 
# back to the original scale using unscale().
preds <- unscale(norm.preds,norm.data)

# Here we evaluate results of the ANN for predicting 
# the correct signals for the test set.

# Function trading.signals() transforms numeric 
# predictions into signals, given the buy and sell
# signals:
sigs.nn <- trading.signals(preds,0.1,-0.1)
true.sigs <- trading.signals(Tdata.train[1001:2000,'T.ind.GSPC'],0.1,-0.1)
# sigs.PR() obtains a matrix with the precision and 
# recall scores of the two types of events, and overall. 
sigs.PR(sigs.nn,true.sigs)

# These scores show the performance of the ANN is not great.
# We have rather low precision scores, and not so interesting
# recall values. The latter are not so serious as they basically 
# mean lost opportunities and not costs.

# On the other hand, low precision scores mean that
# the model gave wrong signals rather frequently.

# ANNs can also be used for classification tasks.
# The  main difference in terms of network topology is that 
# instead of a single output unit, we will have as many output 
# units as there are values of the target variable (or 'class'
# variable. Each of these output units produces a probability
# estimate of the respective class value. 

# So for each test case, an ANN can produce a set of 
# probability values, one for each possible class value.

# We do that here:
set.seed(1234)
library(nnet)
signals <- trading.signals(Tdata.train[,'T.ind.GSPC'],0.1,-0.1)
norm.data <- data.frame(signals=signals,scale(Tdata.train[,-1]))
nn <- nnet(signals ~ .,norm.data[1:1000,],size=10,decay=0.01,maxit=1000,trace=F)
# The type="class" argument is returns a single class label
# for each test case instead of a set of probability estimates.
preds <- predict(nn,norm.data[1001:2000,],type='class')

# With the network predictions we calculate the model
# precision and recall. They are really not better than
# the ones we obtained in the regression task.
sigs.PR(preds,norm.data[1001:2000,1])

###################################################
### Support Vector Machines
###################################################

# Support vector machines (SMVs) are ANN modeling tools
# that can be applied to both regression and 
# classification tasks.

library(e1071)
sv <- svm(Tform,Tdata.train[1:1000,],gamma=0.001,cost=100)
s.preds <- predict(sv,Tdata.train[1001:2000,])
sigs.svm <- trading.signals(s.preds,0.1,-0.1)
true.sigs <- trading.signals(Tdata.train[1001:2000,'T.ind.GSPC'],0.1,-0.1)
sigs.PR(sigs.svm,true.sigs)


library(kernlab)
data <- cbind(signals=signals,Tdata.train[,-1])
ksv <- ksvm(signals ~ .,data[1:1000,],C=10)
ks.preds <- predict(ksv,data[1001:2000,])
sigs.PR(ks.preds,data[1001:2000,1])


library(earth)
e <- earth(Tform,Tdata.train[1:1000,])
e.preds <- predict(e,Tdata.train[1001:2000,])
sigs.e <- trading.signals(e.preds,0.1,-0.1)
true.sigs <- trading.signals(Tdata.train[1001:2000,'T.ind.GSPC'],0.1,-0.1)
sigs.PR(sigs.e,true.sigs)
